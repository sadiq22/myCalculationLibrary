package com.example.mycalculationlibrary

class calculation {
    fun add(a: Int, b: Int): Int {
        return a + b
    }

    fun min(a: Int, b: Int): Int {
        return a - b
    }
}